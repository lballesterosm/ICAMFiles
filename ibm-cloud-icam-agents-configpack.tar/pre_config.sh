#!/bin/sh

if [ "$1" = "real-call" ];then
    shift
    #echo "param: $@"
else
    interpreter=$(command -v bash 2>/dev/null) ||
    interpreter=$(echo $SHELL | grep bash) || 
    interpreter=$(command -v ksh 2>/dev/null) ||
    interpreter=$(echo $SHELL | grep ksh) || 
    interpreter=$(command -v sh 2>/dev/null) ||
    interpreter=$(echo $SHELL | grep /sh)  

    if [ -z "$interpreter" ];then
        ( ls -l /bin/sh | grep bash >/dev/null 2>&1 || 
          ls -l /bin/sh | grep ksh >/dev/null 2>&1 || 
          test -f /bin/sh -a ! -L /bin/sh 2>/dev/null ) && interpreter="/bin/sh"
    fi

    if [ -n "$interpreter" ];then
        echo "Going to run $interpreter $0 $@"
        export interpreter=$interpreter
        exec "$interpreter" "$0" real-call "$@"
        ## exec return 
    else
        echo "Can't find a shell interpreter bash,ksh or sh to run."
        exit 1
    fi
fi

validate_args() {
    validate_srcdir || return 1
	if [ ${COMPRESSED_IMAGES_FOUND} -eq 0 -a ${COMPRESSED_LARGE_IMAGES_FOUND} -eq 0 ]; then
    	# Unpacked image(s) was(were) found so we do pre-configuration
    	# in-situ thus depot dir is src dir in reality.
    	DEPOTDIR="${SRCDIR}"
    else
    	validate_depotdir || return 1
    fi
    return 0
}

#not in use for now
validate_large_image(){
    agentLargeImagesListTar=""
    agentLargeImagesListZip=""
    for file in $(find "${SRCDIR}/." ! -name . -prune -name "*.zip" -o -name "*.tgz" -o -name "*.tar.gz"); do
        case "${file}" in
            *.tgz | *.tar.gz)
                echo "validate large file $file.  tgz_listcmd=${tgz_listcmd}" >>$logfile
                foundoffering=$(${tgz_listcmd} "${file}" 2>/dev/null | grep app_mgmt_agents_dc | grep tar)
                if [ -n "${foundoffering}" ]; then
                    agentLargeImagesListTar="${agentLargeImagesListTar} ${file}"
                fi
                ;;
            *.zip)
                if [ -n "$zip_listcmd" ];then
                    foundoffering=$(${zip_listcmd} "${file}" 2>/dev/null | grep app_mgmt_agents_dc | grep zip)
                else
                    foundoffering=""
                fi
                if [ -n "${foundoffering}" ]; then
                    agentLargeImagesListZip="${agentLargeImagesListZip} ${file}"
                fi
                ;;
        esac
    done
    echo "validate lareg image list: $agentLargeImagesListTar $agentLargeImagesListZip" >>$logfile
    if [ -n "${agentLargeImagesListTar}" -o -n "${agentLargeImagesListZip}" ]; then
        COMPRESSED_LARGE_IMAGES_FOUND=1     
        return 0
    else
        return 1
    fi
}

validate_srcdir() {
    if [ -z "${SRCDIR}" ]; then
        #$NLS-E$ Directory with to-be-configured images not provided.
        nls_replace 'CCM0318E'
        return 1
    fi

    if [ ! -d "${SRCDIR}" ]; then
        #$NLS-E$ Cannot access directory with to-be-configured images $1
        nls_replace 'CCM0319E' "${SRCDIR}"
        return 1
    fi

    SRCDIR=$(cd "${SRCDIR}"; pwd -P)
    echo "Configuring images from $SRCDIR..."
    
    #validate_large_image && return 0

    agentImagesListTar=""
    #agentImagesListTar812=""
    agentImagesListZip=""
    #agentImagesListZip812=""
    #dataCollectorTar=""
    #datacollectorZip=""
    #hybridGatewayTar=""
       
    # Find all *.tar and *.zip files that should be preconfigured. Algorithm
    # first searches for AOF images. If given image is not and AOF image then
    # it is determined whether it is a pre-8.1.3 image.
    for file in $(find "${SRCDIR}/." ! -name . -prune -name "*.tar" -o -name "*.zip" -o -name "*.tgz" -o -name "*.tar.gz"); do
        case "${file}" in
            *.tar)
                foundoffering=$(tar -tf "${file}" 2>/dev/null | grep appmgt* )
                if [ -n "${foundoffering}" ]; then
                    agentImagesListTar="${agentImagesListTar} ${file}"
                fi
                #hybridGatewayTar=$(find "${SRCDIR}/." ! -name . -prune | grep -i "hybrid[^/]*gateway[^/]*\.tar\$" 2> /dev/null)
                #dataCollectorTar=$(find "${SRCDIR}/." ! -name . -prune | grep -i "datacollector[^/]*\.tgz\$" 2> /dev/null)
                ;;
            *.tgz | *.tar.gz)
                foundoffering=$(${tgz_listcmd} "${file}" 2>/dev/null | grep appmgt* )
                if [ -n "${foundoffering}" ]; then
                    agentImagesListTar="${agentImagesListTar} ${file}"
                fi
                ;;    
            *.zip)
                if [ -n "$zip_listcmd" ];then
                    foundoffering=$(${zip_listcmd} "${file}" 2>/dev/null | grep appmgt* )
                else
                    foundoffering=""
                fi
                if [ -n "${foundoffering}" ]; then
                    agentImagesListZip="${agentImagesListZip} ${file}"
                fi
                #dataCollectorZip=$(find "${SRCDIR}/." ! -name . -prune | grep -i "datacollector[^/]*\.zip\$" 2> /dev/null)
               ;;
        esac
    done
    echo "validate src dir. file list: $agentImagesListTar $agentImagesListZip" >> $logfile
    if [ -n "${agentImagesListTar}" -o -n "${agentImagesListZip}" ]; then
         #-n "${dataCollectorTar}" -o  -n "${dataCollectorZip}" ]; then
        COMPRESSED_IMAGES_FOUND=1
        return 0
    else
        
        # Find all AOF images. AOF image is recognised by the presence of
        # offering.properties file.
        agentimageslist=$(find "${SRCDIR}/." -name appmgt* 2>/dev/null | awk -F "/" '{ for (i=1; i<=NF-2; i++) printf("%s/", $i); printf("\n") }' 2>/dev/null)
        #hybridgateway=$(find "${SRCDIR}/." ! -name . -prune -name "*_Hybrid_Gateway_*" 2>/dev/null)

        if [ -z "${agentimageslist}" ]; then
            # $NLS-E$ No to-be-configured images found in $1
            echo "$(nls_replace CCM0320E "${SRCDIR}")"
            echo "Note that this script is from release 2019.2.1 and it is not compatible with agent installation images in release 2018.4.1 or earlier."
            return 1
        fi
    fi

    return 0
}

validate_depotdir() {
    if [ -z "${DEPOTDIR}" ]; then
        #$NLS-E$ Depot directory not provided. Using default $1
        nls_replace 'CCM0321I' "${DEFAULTDEPOTDIR}"
        DEPOTDIR="${DEFAULTDEPOTDIR}"
    fi

    if [ ! -d "${DEPOTDIR}" ]; then
        cdir=$(pwd -P)
        mkdir -p "${DEPOTDIR}" > /dev/null 2>&1
        cd "${DEPOTDIR}"
        if [ $? -ne 0 ]; then
            #$NLS-E$ Could not create depot directory $1
            nls_replace 'CCM0322E' "${DEPOTDIR}"
            return 1
        fi
        DEPOTDIR=$(pwd -P)
        cd "${cdir}"
    fi

    DEPOTDIR=$(cd "${DEPOTDIR}"; pwd -P)

    touch "${DEPOTDIR}"/${MYNAME}.test 2>/dev/null
    if [ $? -ne 0 ]; then
        #$NLS-E$ Unable to write to depot directory $1
        nls_replace 'CCM0323E' "${DEPOTDIR}"
        return 1
    fi

    rm -rf "${DEPOTDIR}"/${MYNAME}.test 2>/dev/null

    return 0
}

usage() {
    #$NLS-E$ $1 -p <configuration_package_dir> -s <agent_images_dir> [...]
    ${echo_e} "$(nls_replace 'CCM0314I')"
}

getSuffix(){
    __filename=${1}
    __suffix=$(echo "${__filename}" | awk -F "." '{print $NF}')
    if [ "$__suffix" = "gz" ];then
        __suffix2=$(echo "${__filename}" | awk -F "." '{print $(NF-1)}')
        if [ "$__suffix2" = "tar" ];then
            __suffix="tar.gz"
        fi
    fi
    echo $__suffix
}

customize_packed_large_images() {
    mkdir -p ${WORKDIR}/temp_images1
    mkdir -p ${WORKDIR}/temp_images
    cd ${WORKDIR}/temp_images1
    for large_img in ${1}; do
        suffix=$(getSuffix ${large_img})
        #prepare_configs ${suffix}
        case "${large_img}" in
            *.tgz | *.tar.gz)
                unpackcmd=$tgz_unpackcmd
                ;;
            *.zip)
                unpackcmd=$zip_unpackcmd
                ;;
        esac
        echo "extracting ${large_img} to ${WORKDIR}/temp_images1" >>$logfile
        echo "unpack command is $unpackcmd " >>$logfile
        ${unpackcmd} "${large_img}" >/dev/null 2>&1
        foldername1=$(echo $large_img | awk -F ".${suffix}" '{print $1}')
        foldername=$(echo $foldername1 | awk -F "/" '{print $NF}')
        echo "foldername=$foldername" >> $logfile
        echo "moving ${foldername}/* to ${WORKDIR}/temp_images" >>$logfile
        echo "files in ${WORKDIR}/temp_images1/$foldername:" >>$logfile 
        ls -l  ${WORKDIR}/temp_images1/$foldername >>$logfile 2>&1
        mv ${WORKDIR}/temp_images1/${foldername}/* ${WORKDIR}/temp_images
    done
    cd ${WORKDIR}
    SRCDIR=${WORKDIR}/temp_images
    echo "files in $SRCDIR:" >>$logfile
    ls -l $SRCDIR >>$logfile 2>&1
    validate_srcdir || return 1
    if [ ${COMPRESSED_IMAGES_FOUND} -eq 1 ]; then
        customize_packed_images_aof
        rc=$?
    else
        log_echo "Can't find configurable images from $1."
        rc=1
    fi
    return ${rc}            
}

customize_agents() {
    rc=0

    if [ ${COMPRESSED_LARGE_IMAGES_FOUND} -eq 1 ];then
        customize_packed_large_images "${agentLargeImagesListTar} ${agentLargeImagesListZip}"
        rc=$?
    elif [ ${COMPRESSED_IMAGES_FOUND} -eq 1 ]; then
        customize_packed_images_aof
        rc=$?
    else
        customize_unpacked_images_aof
        rc=$?
    fi
    
    return ${rc}
}

customize_packed_images_aof() {
    customize_packed_images "${agentImagesListTar} ${agentImagesListZip}" false
}

customize_unpacked_images_aof() {
    customize_unpacked_images "${agentimageslist}" true
}

customize_packed_images() {
    img=""
    cfgprepared=""
    __result=0
    # onetime to record success/failed for each img in the loop.
    __onetime=1
    # Main loop. Do the image configuration for each image found in source dir.
    # The order is important. Hybrid Gateway must be after *.zip agents so that
    # pack/unpack commands are properly set by prepare_configs() function.
    for img in ${1}; do
        packagename=$(basename "${img}")
        imgCountTotal=$((imgCountTotal + 1))
        
        # Prepare configuration files based on the file name extension. Assume
        # that tar/tgz means Linux/UNIX and zip means Windows. Do the preparation
        # only once for each of the platforms. Then get the name of the unpacked
        # image.
        #suffix=$(echo "${img}" | awk -F "." '{print $NF}')
        suffix=$(getSuffix ${img})
        prepare_configs ${suffix} 
        case ${suffix} in
            tar | tgz | tar.gz)
                imgname=$(${listcmd} "${img}" 2>/dev/null | head -1 | cut -d "/" -f 1)
                ;;
            zip)
                if [ -n "zip_tool" -a -n "unzip_tool" ];then
                #if [ "${zip_tool}" = "zip" -o "${unzip_tool}" = "unzip" ];then
                    imgname=$(${listcmd} "${img}" 2>/dev/null | head -5 | tail -1 | \
                        tr -s " " | cut -d " " -f 5 | cut -d "/" -f 1)
                elif [ "$os" = "AIX" ]; then
                    #$NLS-E$ Image $1 can not be configured on this AIX system. Use a Linux system to configure this image.
                    nls_replace 'CCM0512I' "${imgname}.${suffix}"
                    continue
                fi
                ;;
        esac

    ###__        validate_prerequisite_versions "${img}"
    ###__        [ $? -eq 1 ] && continue

        # Check if there's enough room to do the pre-configuration.
        # We need twice as much as image size because we need to unpack it
        # (1 imgsize) and then pack it in new place (2 imgsize).
        # will not check disk space since df command may hang on the system that has unvailable mount point.
        # imgsize=$(du -m "${img}" | sed s'/^ //' | cut -f 1)
        # imgsize=$(($imgsize + $imgsize))
        # check_disk_space "${workdir}" ${imgsize} || return 1

        ##############
        #$NLS-E$ Configuring $1
        nls_replace 'CCM0336I' "${packagename}"
        ${unpackcmd} "${img}" >>$logfile  2>&1
        if [ $? -eq 0 ];then
            ## Customize image
        	do_customization_work "${img}" "${2}"
        	ret=$?
        	if [ $ret -eq 0 ];then
        		# create new image and put to the depot.
                echo "customize_packed_images. packcmd=$packcmd." >>$logfile
        		${packcmd} "${DEPOTDIR}"/${packagename} ${imgname} >/dev/null 2>&1
        		if [ $? -eq 0 ]; then
            		#$NLS-E$ Successfully configured $1.
            		nls_replace 'CCM0338I' "${packagename}"
            		imgCountSuccess=$((imgCountSuccess + 1))
            		__onetime=0
        		else
            		#$NLS-E$ Failed configuring $1.
            		nls_replace 'CCM0339E' "${packagename}"
        		fi
        	elif [ $ret -eq 2 ];then
        		# already pre-configured
        	    __onetime=0
                imgCountSkip=$((imgCountSkip + 1))	
        	else
   				echo "Failed to pre-configure ${img}"
        	fi	
        else
            #$NLS-E$ Failed to unpack $1
            nls_replace 'CCM0337E' "$packagename" 
        fi
        if [ $__onetime -eq 1 ];then
        	imgCountFail=$((imgCountFail + 1))
            __result=1
        fi
		rm -rf ${imgname}
    done

    return $__result
}

customize_unpacked_images() {
    imgname=""
    platform=""
    __result=0
    __retval=0
    # Main loop.  Do the image configuration for each image found in source dir.
    for imgname in ${1}; do
        
        # We have to reset that variable so that pack/unpack variables are
        # properly set for each image. It is caused by the fact the we don't
        # know if the image that we currently work on is Linux/UNIX or Windows
        # so we must set those variables for each image.
        cfgprepared=""
        platform=$(ipm_offering_get_platform "${imgname}") 
        case ${platform} in
            windows*)
                prepare_configs "zip"
				#validate_prerequisite_versions "${imgname}"
                #[ $? -eq 1 ] && continue
                do_customization_work "${imgname}" "${2}" 
                __retval=$?
                ;;
            *linux*|aix*)
                prepare_configs "tar"
                #validate_prerequisite_versions "${imgname}"
                #[ $? -eq 1 ] && continue
                do_customization_work "${imgname}" "${2}" 
                __retval=$?
                ;;
            *)
                __retval=9
                echo "Can not determine platform for ${imgname}"
                ;;    
        esac

		if [ $__retval -eq 0 ]; then
            #$NLS-E$ Successfully configured $1.
            nls_replace 'CCM0338I' "${imgname}"
        elif [ $__retval -eq 2 ];then
        	# already pre-configured
            :    
        else
            #$NLS-E$ Failed configuring $1.
            nls_replace 'CCM0339E' "${imgname}"
            __result=$__retval
        fi
    done

    return $__result
}

aix_listcmd() {
    if [ -n "$1" ];then
        gunzip -c $1 | tar -tf - 2>/dev/null
    fi 
}

aix_unpackcmd() {
    if [ -n "$1" ];then
        gunzip -c $1 | tar -xf - 2>/dev/null
    fi
}

# $1 output tar.gz file, $2 src dir
aix_packcmd() {
    if [ -n "$1" -a -n "$2" ];then
        echo "tar -cvf - $2 | gzip \> $1" >> $logfile
        tar -cvf - $2 | gzip > $1
    fi
}

prepare_configs() {
    #local config_package_suffix
    #local config_package_unpack_cmd
    
            # Linux/UNIX
    if [ "${1}" = "tar" -o "${1}" = "tgz" -o "${1}" = "tar.gz" ]; then
        cfgdir=".${IMGTYPE}_config"
        cfgfile="agent_global.environment"
        custcfgdir="$CUSTPKGDIR"
        dot="."
        tenantidFile=".tenantid.txt"
        if [ ${1} = "tar" ]; then
            listcmd="tar -tf"
            packcmd="tar -cf"
            unpackcmd="tar -xf"
        else
            listcmd="$tgz_listcmd"
            packcmd="$tgz_packcmd"
            unpackcmd="$tgz_unpackcmd"
        fi
    fi

    # Windows
    if [ "${1}" = "zip" ]; then
        cfgdir="${IMGTYPE}_config"
        cfgfile="framework_silent_install.txt"
        #config_package_suffix="zip"
        #config_package_unpack_cmd="unzip -qo"
        custcfgdir="$CUSTPKGDIR"
        dot=""
        #listcmd="zipinfo -1"
        listcmd="$zip_listcmd"
        #packcmd="zip -qr"
        packcmd="$zip_packcmd"
        #protocolFile="protocol.txt"
        tenantidFile="tenantid.txt"
        #unpackcmd="unzip -qo"
        unpackcmd="$zip_unpackcmd"
    fi
    cfg_Server_minimum_version=$(ipm_get_value "^smaiVersion" "${custcfgdir}/versions/version_product.properties")
    cfg_Framework_minimum_version=$(ipm_get_value "^frameworkVersion" "${custcfgdir}/versions/version_framework.properties")
    # No empty strings allowed.
    [ -z "${cfg_Server_minimum_version}" ] && cfg_Server_minimum_version=0
    [ -z "${cfg_Framework_minimum_version}" ] && cfg_Framework_minimum_version=0

    return 0
}

# this function is not used since df -kP may hang.
check_disk_space() {
    dfcmd="df -kP"
    dffilter="| grep '%' | head -1 | awk '{av=NF-2; print \$av}'"

    kbmax=2147483647
    kbavail=$(eval ${dfcmd} ${1} 2>/dev/null ${dffilter})

    if [ -n "${kbavail}" ]; then
        if [ ${kbavail} -gt ${kbmax} ]; then
            kbavail=${kbmax}
        fi
    else
        #$NLS-E$ 'df' could not determine the available disk space in "$1"
        nls_replace 'CCM0333E'
        return 1
    fi

    if [ ${kbavail} -lt ${2} ]; then
        #$NLS-E$ Not enough space in $1 to perform image pre-configuration (required $2 KB).
        nls_replace 'CCM0334E' "$1" "$2"
        return 1
    fi

    return 0
}

do_customization_work() {
    case $(basename "${1}") in
        *_hybrid_gateway_*)
            #do_hybrid_gateway_customization_work "$@"
            ;;
        *_datacollectors_*)
            #dataCollectorPackage="yes"
            #do_datacollectors_customization_work "$@"
            ;;
        *)
            do_agents_customization_work "$@"
            ;;
    esac
}

do_agents_customization_work() {
    #IS_AOF_PKG="${2}"
    grep -q "#asf_base_url#" "${imgname}/${cfgdir}/${cfgfile}" >/dev/null 2>&1
    if [ $? -eq 1 ]; then
        #$NLS-E$ The image $1 is already pre-configured.
        nls_replace 'CCM0335E' "$1"
        return 2
    fi

    # Copy agent framework
    platform=$(ipm_offering_get_platform "${imgname}")
    if [ -z "${platform}" ]; then
        
        #$NLS-E$ Failed to retrieve the platform name for the agent offering.
        nls_replace 'CCM0439E'
        return 1
    fi

    if [ "${IMGTYPE}" != "apm" ]; then
        /bin/mv "${imgname}"/${dot}apm "${imgname}"/${dot}${IMGTYPE} || return 1
        /bin/mv "${imgname}"/${dot}apm_config "${imgname}"/${dot}${IMGTYPE}_config || return 1
    fi
 
    # Customize image
    #mkdir "${imgname}/${cfgdir}/keyfiles/"
    #/bin/cp -r "${custcfgdir}"/keyfiles/* "${imgname}/${cfgdir}/keyfiles/"
    if [ -d "${CDIR}"/keyfiles ];then
        echo "copy keyfiles:" >>$logfile
        ls ${CDIR}/keyfiles/keyfile* >>$logfile 2>&1
        /bin/cp -f "${CDIR}"/keyfiles/keyfile* "${imgname}/${cfgdir}/keyfiles/" 2>/dev/null
    fi
 #   /bin/cp -r "${custcfgdir}"/${tenantidFile} "${imgname}/${cfgdir}/${tenantidFile}"
    #if [ ! -f "${imgname}/${cfgdir}/${cfgfile}" ];then
    #    /bin/cp -r "${custcfgdir}"/${cfgfile} "${imgname}/${cfgdir}/${cfgfile}"
    #fi
   # /bin/cp -f "${custcfgdir}"/installAPMAgents.sh  "${imgname}/installAPMAgents.sh"
    #/bin/cp -f "${custcfgdir}"/installAPMAgents.bat  "${imgname}/installAPMAgents.bat"
    echo "$winterfell_tenantid" > "${imgname}/${cfgdir}/${tenantidFile}"
    #chmod +x "${imgname}/.apm/smai-agent.sh"
    #chmod +x "${imgname}/.apm/nls/nls_replace_ccm"
 #   tenantid=$(cat "${custcfgdir}"/${tenantidFile} | sed 's/ *$//g' | tr -d '\015')
 #   baseURL=$(grep BASE_URL "${custcfgdir}"/agent_global_env.cfg | cut -d "=" -f 2 | sed 's#/*$##')
    #serverauth=$(grep ITM_AUTHENTICATE_SERVER_CERTIFICATE "${custcfgdir}"/agent_global_env.cfg | sed 's#/*$##') 
    update_file "s!#asf_base_url#!${winterfell_baseURL}!g" "${imgname}/${cfgdir}/${cfgfile}"  || return 1
    update_file "s!#ira_api_tenant_id#!${winterfell_tenantid}!g" "${imgname}/${cfgdir}/${cfgfile}" || return 1
    #update_file "s\"!ITM_AUTHENTICATE_SERVER_CERTIFICATE=.!${serverauth}!\"g" "${imgname}/${cfgdir}/${cfgfile}"
    if [ "$PROTOCOL" = "https" -o "$PROTOCOL" = "HTTPS" ];then
        case "${platform}" in 
            windows*)
                $echo_e "KEYFILE_DIR=\$(CANDLE_HOME)\keyfiles\r" >> "${imgname}/${cfgdir}/${cfgfile}"
                $echo_e "GSK_KEYRING_FILE=\$(CANDLE_HOME)\keyfiles\keyfile.kdb\r" >> "${imgname}/${cfgdir}/${cfgfile}"
                $echo_e "GSK_KEYRING_STASH=\$(CANDLE_HOME)\keyfiles\keyfile.sth\r" >> "${imgname}/${cfgdir}/${cfgfile}"
                $echo_e "GSK_KEYRING_LABEL=IBM_Tivoli_Monitoring_Certificate\r" >> "${imgname}/${cfgdir}/${cfgfile}"
                $echo_e "ICCRTE_DIR=\$(CANDLE_HOME)\GSK8_x64\r" >> "${imgname}/${cfgdir}/${cfgfile}"
                $echo_e "GSK_SSL_EXTN_SERVERNAME_REQUEST=${SERVER}\r" >> "${imgname}/${cfgdir}/${cfgfile}"
                $echo_e "JAEGER_ENDPOINT=${JAEGER_ENDPOINT_URL}\r" >> "${imgname}/${cfgdir}/${cfgfile}"
                $echo_e "JAEGER_ENDPOINT_ZIPKIN=${JAEGER_ENDPOINT_ZIPKIN}\r" >> "${imgname}/${cfgdir}/${cfgfile}"
                $echo_e "JAEGER_ENDPOINT_ZIPKIN_V2=${JAEGER_ENDPOINT_ZIPKIN_V2}\r" >> "${imgname}/${cfgdir}/${cfgfile}"
                $echo_e "ICAM_KEYFILE=${ICAM_KEYFILE}\r" >> "${imgname}/${cfgdir}/${cfgfile}"
                $echo_e "ICAM_KEYFILE_PSWD=${ICAM_KEYFILE_PSWD}\r" >> "${imgname}/${cfgdir}/${cfgfile}"
                $echo_e "IBM_APM_SERVER_INGRESS_URL=${IBM_APM_SERVER_INGRESS_URL}\r" >> "${imgname}/${cfgdir}/${cfgfile}"
                $echo_e "RESOURCEMGMT_SERVICE_BASE_PATH=${RESOURCEMGMT_SERVICE_BASE_PATH}\r" >> "${imgname}/${cfgdir}/${cfgfile}"

                
                $echo_e "IRA_ASF_SERVER_URL=${winterfell_baseURL}/ccm/asf/request\r" > "${imgname}/${cfgdir}/global.environment"
                $echo_e "IRA_API_DATA_BROKER_URL=${winterfell_baseURL}/1.0/monitoring/data\r" >> "${imgname}/${cfgdir}/global.environment"
                $echo_e "IRA_API_TENANT_ID=${winterfell_tenantid}\r" >> "${imgname}/${cfgdir}/global.environment"
                $echo_e "JAEGER_ENDPOINT=${JAEGER_ENDPOINT_URL}\r" >> "${imgname}/${cfgdir}/global.environment"
                $echo_e "JAEGER_ENDPOINT_ZIPKIN=${JAEGER_ENDPOINT_ZIPKIN}\r" >> "${imgname}/${cfgdir}/global.environment"
                $echo_e "JAEGER_ENDPOINT_ZIPKIN_V2=${JAEGER_ENDPOINT_ZIPKIN_V2}\r" >> "${imgname}/${cfgdir}/global.environment"
                $echo_e "ICAM_KEYFILE=${ICAM_KEYFILE}\r" >> "${imgname}/${cfgdir}/global.environment"
                $echo_e "ICAM_KEYFILE_PSWD=${ICAM_KEYFILE_PSWD}\r" >> "${imgname}/${cfgdir}/global.environment"
                $echo_e "IBM_APM_SERVER_INGRESS_URL=${IBM_APM_SERVER_INGRESS_URL}\r" >> "${imgname}/${cfgdir}/global.environment"
                $echo_e "RESOURCEMGMT_SERVICE_BASE_PATH=${RESOURCEMGMT_SERVICE_BASE_PATH}\r" >> "${imgname}/${cfgdir}/global.environment"

                ;;
            *)    
                echo "KEYFILE_DIR=\${CANDLEHOME}/keyfiles" >> "${imgname}/${cfgdir}/${cfgfile}"
                echo "GSK_KEYRING_FILE=\${CANDLEHOME}/keyfiles/keyfile.kdb" >> "${imgname}/${cfgdir}/${cfgfile}"
                echo "GSK_KEYRING_STASH=\${CANDLEHOME}/keyfiles/keyfile.sth" >> "${imgname}/${cfgdir}/${cfgfile}"
                echo "GSK_KEYRING_LABEL=IBM_Tivoli_Monitoring_Certificate" >> "${imgname}/${cfgdir}/${cfgfile}"
                echo "ICCRTE_DIR=\${CANDLEHOME}/\${GSKARCH}/gs" >> "${imgname}/${cfgdir}/${cfgfile}"
                echo "GSK_SSL_EXTN_SERVERNAME_REQUEST=${SERVER}" >> "${imgname}/${cfgdir}/${cfgfile}"
                echo "JAEGER_ENDPOINT=${JAEGER_ENDPOINT_URL}" >> "${imgname}/${cfgdir}/${cfgfile}"
                echo "JAEGER_ENDPOINT_ZIPKIN=${JAEGER_ENDPOINT_ZIPKIN}" >> "${imgname}/${cfgdir}/${cfgfile}"
                echo "JAEGER_ENDPOINT_ZIPKIN_V2=${JAEGER_ENDPOINT_ZIPKIN_V2}" >> "${imgname}/${cfgdir}/${cfgfile}"
                echo "ICAM_KEYFILE=${ICAM_KEYFILE}" >> "${imgname}/${cfgdir}/${cfgfile}"
                echo "ICAM_KEYFILE_PSWD=${ICAM_KEYFILE_PSWD}" >> "${imgname}/${cfgdir}/${cfgfile}"
                echo "IBM_APM_SERVER_INGRESS_URL=${IBM_APM_SERVER_INGRESS_URL}" >> "${imgname}/${cfgdir}/${cfgfile}"
                echo "RESOURCEMGMT_SERVICE_BASE_PATH=${RESOURCEMGMT_SERVICE_BASE_PATH}" >> "${imgname}/${cfgdir}/${cfgfile}"
                ;;
        esac
    fi

    if [ "$custom_cert" = "yes" ];then
        grep -v KDEBE_FIPS_MODE_ENABLED "${imgname}/${cfgdir}/${cfgfile}" > tempfile_FIPS
        mv tempfile_FIPS "${imgname}/${cfgdir}/${cfgfile}"
    fi
    return 0
}

# Determine image's platform. First try to get the platform from the
# offering.properties file (for 8.1.3 and later releases). If the file doesn't
# exist then try to determine platform based on the TEMA (for pre-8.1.3
# release). In the latter case we care only if it's windows, linux or aix, so
# we don't differentiate between 32 and 64 bit (this is becase TEMA is already
# present in the installation image and we don't have to copy it from the
# AOFPKGDIR.
ipm_offering_get_platform() {
    case "${1}" in
        *.tar|*.tgz)
            _ipmo_platform=$(tar -xf "${1}" -O */*/offering.properties 2>/dev/null \
                | grep "^IPMO_PLATFORM" 2>/dev/null | cut -d "=" -f 2 | sed s'/^ //' | sed s'/ $//')
            if [ -z "${_ipmo_platform}" ]; then
                
                # Search pre-8.1.3 image.
                _platform=$(tar -tf "${1}" 2>/dev/null | grep core-framework | \
                    grep -e ".*ax.*.tgz" | awk -F "/" '{printf("%s\n", $NF)}' | cut -d "." -f 1)
                case "${_platform}" in
                    axaix*)
                        _ipmo_platform="aix"
                        ;;
                    axlx*)
                        _ipmo_platform="xlinux"
                        ;;
                    *)
                        return 1
                        ;;
                esac
            fi
            ;;
        *.zip)
            _ipmo_platform=$(unzip -p "${1}" */*/offering.properties 2>/dev/null \
                | grep "^IPMO_PLATFORM" 2>/dev/null | cut -d "=" -f 2 | sed s'/^ //' | sed s'/ $//')
            if [ -z "${_ipmo_platform}" ]; then
                _ipmo_platform="windows"
            fi
            ;;
        *)
            _offering_properties=$(find "${1}" -name offering.properties 2>/dev/null)
            if [ -n "${_offering_properties}" ]; then
                _ipmo_platform=$(ipm_get_value "^IPMO_PLATFORM" "${_offering_properties}") || return 1
            else
                # Search pre-8.1.3 image.
                _platform=$(find "${1}" -name ax*.tgz -o -name KGL*.exe 2>/dev/null | awk -F "/" '{printf("%s\n", $NF)}' | cut -d "." -f 1)
                case "${_platform}" in
                    axaix*)
                        _ipmo_platform="aix"
                        ;;
                    axlx*)
                        _ipmo_platform="xlinux"
                        ;;
                    KGL*)
                        _ipmo_platform="windows"
                        ;;
                    *)
                        return 1
                        ;;
                esac
          fi    
        ;;
    esac

    echo "${_ipmo_platform}"

    return 0
}

ipm_get_value() {
    [ ! -f "${2}" ] && return 1
    _properties_entry=$(grep "${1}" "${2}" 2>/dev/null | cut -f2 -d= | sed s'/^ //' | sed s'/ $//')
    
    # Did not find the entry so return with error code.
    [ -z "${_properties_entry}" ] && return 1
    echo "${_properties_entry}"

    return 0
}

update_file() {
    expression="$1"
    file="$2"
    tmp="${file}.$$"
    eval "sed $expression \"$file\" > \"$tmp\""
    ret=$?
    mv -f "$tmp" "$file"
    return $ret
}

read_input() {
    prompt="${1}"
    variable="${2}"
    [ "$os" = "Linux" ] && cmd="read -e -r -p \"$prompt\" $variable"
    [ ! "$os" = "Linux" ] && cmd="read -r $variable?\"$prompt\""
    eval $cmd
}

readenvfile() {
    __ENVPROPFILE=$1
    if [ -f "$__ENVPROPFILE" ]; then
        SERVER=`grep ^hostname "$__ENVPROPFILE" 2>/dev/null | cut -f 2 -d '='`
        if [ -z "$SERVER" ];then
            log_echo "Failed to get server from ENV file."
            return 1
        fi
        __PORT=`grep ^port "$__ENVPROPFILE" 2>/dev/null | cut -f 2 -d '='`
        if [ -z "$__PORT" ];then
            log_echo "Failed to get port from ENV file."
            return 1
        fi
        PROTOCOL=`grep ^protocol "$__ENVPROPFILE" 2>/dev/null | cut -f 2 -d '='`
        if [ -z "$PROTOCOL" ];then
            log_echo "Failed to get protocol from ENV file."
            return 1
        fi
        winterfell_baseURL=${PROTOCOL}://${SERVER}:${__PORT}
        winterfell_tenantid=`grep ^tenantid "$__ENVPROPFILE" 2>/dev/null | cut -f 2 -d '='`
        if [ -z "$winterfell_tenantid" ];then
            log_echo "Failed to get tenant id from ENV file."
            return 1
        fi

        JAEGER_ENDPOINT_URL=`grep ^jaeger_endpoint_url "$__ENVPROPFILE" 2>/dev/null | cut -f 2- -d '='`
        if [ -z "$JAEGER_ENDPOINT_URL" ];then
            log_echo "Failed to get jaeger_endpoint from ENV file."
            return 1
        fi

        JAEGER_ENDPOINT_ZIPKIN=`grep ^jaeger_endpoint_zipkin= "$__ENVPROPFILE" 2>/dev/null | cut -f 2- -d '='`
        if [ -z "$JAEGER_ENDPOINT_ZIPKIN" ];then
            log_echo "Failed to get jaeger_endpoint_zipkin from ENV file."
            return 1
        fi

        JAEGER_ENDPOINT_ZIPKIN_V2=`grep ^jaeger_endpoint_zipkin_v2= "$__ENVPROPFILE" 2>/dev/null | cut -f 2- -d '='`
        if [ -z "$JAEGER_ENDPOINT_ZIPKIN_V2" ];then
            log_echo "Failed to get jaeger_endpoint_zipkin_v2 from ENV file."
            return 1
        fi

        ICAM_KEYFILE=`grep ^icam_keyfile_name "$__ENVPROPFILE" 2>/dev/null | cut -f 2- -d '='`
        if [ -z "$ICAM_KEYFILE" ];then
            log_echo "Failed to get icam_keyfile from ENV file."
            return 1
        fi

        ICAM_KEYFILE_PSWD=`grep ^icam_keyfile_pswd "$__ENVPROPFILE" 2>/dev/null | cut -f 2- -d '='`
        if [ -z "$ICAM_KEYFILE_PSWD" ];then
            log_echo "Failed to get icam_keyfile_pswd from ENV file."
            return 1
        fi

        custom_cert=`grep ^custom_cert "$__ENVPROPFILE" 2>/dev/null | cut -f 2- -d '='`

        RESOURCEMGMT_SERVICE_BASE_PATH=`grep ^RESOURCEMGMT_SERVICE_BASE_PATH "$__ENVPROPFILE" 2>/dev/null | cut -f 2- -d '='`
        IBM_APM_SERVER_INGRESS_URL=`grep ^IBM_APM_SERVER_INGRESS_URL "$__ENVPROPFILE" 2>/dev/null | cut -f 2- -d '='`

    else
        log_echo "ENV file $__ENVPROPFILE does not exist!"
        return 1
    fi
    return 0
}

checkZIP() {
    zip_not_found=$(zip -h 2>&1 | grep "not found")
    unzip_not_found=$(unzip -v 2>&1 | grep "not found")
    jar_not_found=$(jar 2>&1 | grep "not found")
    zipinfo_not_found=$(zipinfo 2>&1 | grep "not found")
    if [ -z "$zipinfo_not_found" ];then
        zip_listcmd="zipinfo -1"
    elif [ -z "$unzip_not_found" ]; then
        zip_listcmd="unzip -qql"
    elif [ -z "$jar_not_found" ];then
        zip_listcmd="jar -tf"
    fi

    if [ -z "$zip_not_found" ];then
        zip_tool="zip"
        zip_packcmd="zip -qr"
    elif [ -z "$jar_not_found" ];then
        zip_tool="jar"
        zip_packcmd="jar -cfM"
    fi

    if [ -z "$unzip_not_found" ];then
        unzip_tool="unzip"
        zip_unpackcmd="unzip -qo"
    elif [ -z "$jar_not_found" ];then
        unzip_tool="jar"
        zip_unpackcmd="jar -xf"
    fi
    echo "zip_listcmd=$zip_listcmd" >>$logfile
    echo "zip_packcmd=$zip_packcmd" >>$logfile
    echo "zip_unpackcmd=$zip_unpackcmd" >>$logfile

    if [ -z "$zip_tool" -o -z "$unzip_tool" ];then
        log_echo "Can not find zip or jar command. ZIP file can not be configured on this system."
    fi
}

checkTAR() {
    if [ "$os" = "AIX" ];then
        tgz_listcmd="aix_listcmd"
        tgz_unpackcmd="aix_unpackcmd"
        tgz_packcmd="aix_packcmd"
    else
        tgz_listcmd="tar -tzf"
        tgz_packcmd="tar -czf"
        tgz_unpackcmd="tar -xzf"
    fi    
}

log_echo()
{
    echo "$1"
    echo "$1" >>$logfile
}

checkECHO() {
    # determine is -e is an available parameter for echo.
    # On Aix, /bin/sh echo doesn't support -e and it can parse \r \n by default
    e_not_support=$(echo -e aaa | grep "e")
    if [ -z "$e_not_support" ];then
        echo_e="echo -e"
    else
        # usually this is for /bin/sh on AIX
        echo_e="echo"
    fi
}


################# main #####################
winterfell_baseURL=
winterfell_tenantid=
PROTOCOL=
SERVER=
JAEGER_ENDPOINT_URL=
JAEGER_ENDPOINT_ZIPKIN=
JAEGER_ENDPOINT_ZIPKIN_V2=
ICAM_KEYFILE=
ICAM_KEYFILE_PSWD=
custom_cert=

CDIR=$(cd $(dirname "$0"); pwd -P)
CUSTPKGDIR=${CDIR}
INSTALL_DIR=$(cd ${CDIR}/..; pwd -P)
MYNAME=$(basename $0)
DEFAULTDEPOTDIR=$INSTALL_DIR/depot
logfile=${CDIR}/pre_config.log
touch $logfile
if [ ! -f $logfile ];then
    echo "Can't create $logfile."
    logfile="/dev/null"
fi
echo "==========================`date`===========================" >> $logfile

[ ! -x "$CDIR"/nls_replace ] && log_echo "Script $CDIR/nls_replace not found, cannot continue" && exit 1
[ ! -d "$CDIR"/msg ] && log_echo "Directory $CDIR/msg not found, cannot continue" && exit 1
export PATH=$CDIR:$PATH

os="$(uname -s)"

#By default alias doesn't work in shell script. So need to check echo -e
checkECHO

IMGTYPE=apm

if [ $# -eq 0 ]; then
    usage
    exit 0
fi

while getopts "d:e:hs:" opt ; do
    case ${opt} in
        d)
            DEPOTDIR="${OPTARG}"
            ;;
		e)
			ENVPROPFILE="${OPTARG}"
			;;
        h)
            usage
            exit 0
            ;;
        s)
            SRCDIR="${OPTARG}"
            ;; 
        *)
            usage
            exit 1
    esac
done

if [ -z "${ENVPROPFILE}" ];then 
    ENVPROPFILE="${CDIR}/env.properties"
fi 
readenvfile "$ENVPROPFILE"
if [ $? -ne 0 ]; then
    exit 1
fi

COMPRESSED_IMAGES_FOUND=0
COMPRESSED_LARGE_IMAGES_FOUND=0
IS_JRE_REQUIRED="false"

checkZIP
checkTAR
# Batch mode.
validate_args || exit 1


WORKDIR="${DEPOTDIR}"/workdir
if [ ! -d "${WORKDIR}" ]; then
    mkdir "${WORKDIR}"
    if [ $? -ne 0 ]; then
        #$NLS-E$ Could not create temporary work directory $1.
        nls_replace 'CCM0342E' "${WORKDIR}"
        exit 1
    fi
fi

cd "${WORKDIR}"

#Initialize image processing counters
imgCountTotal=0
imgCountFail=0
imgCountSuccess=0
imgCountSkip=0

rc=0
customize_agents
if [ $? -ne 0 ]; then
    rc=$(($rc + 1))
fi

if [ "${imgCountTotal}" -gt 0 ]; then
    [ "${imgCountTotal}" -gt 1 ] && iCT=s || iCT=""
    #$NLS-E$ $1 Agent image$2 $3.
    nls_replace 'CCM0492W' "${imgCountTotal}" "${iCT}" "total"
fi
if [ "${imgCountSuccess}" -gt 0 ]; then
    [ "${imgCountSuccess}" -gt 1 ] && iCS=s || iCS=""
    #$NLS-E$ $1 Agent image$2 added to $3.
    nls_replace 'CCM0343I' "${imgCountSuccess}" "${iCS}" "${DEPOTDIR}"
fi
if [ "${imgCountFail}" -gt 0 ]; then
    [ "${imgCountFail}" -gt 1 ] && iCF=s || iCF=""
    #$NLS-E$ $1 Agent image$2 $3.
    nls_replace 'CCM0492W' "${imgCountFail}" "${iCF}" "failed"
fi
if [ "${imgCountSkip}" -gt 0 ]; then
    [ "${imgCountSkip}" -gt 1 ] && iCK=s || iCK=""
    #$NLS-E$ $1 Agent image$2 $3.
    nls_replace 'CCM0492W' "${imgCountSkip}" "${iCK}" "skipped"
fi

cd "$CDIR"

rm -rf "${WORKDIR}"

exit ${rc}
